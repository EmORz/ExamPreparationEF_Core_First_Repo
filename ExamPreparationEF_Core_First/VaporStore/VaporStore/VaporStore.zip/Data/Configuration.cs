﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
        //todo test conection to server!!!
	}
}