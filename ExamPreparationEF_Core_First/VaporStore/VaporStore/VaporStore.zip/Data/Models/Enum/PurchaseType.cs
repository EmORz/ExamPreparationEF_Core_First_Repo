﻿namespace VaporStore.Data.Models.Enum
{
    public enum PurchaseType
    {
        Digital,
        Retail
    }
}